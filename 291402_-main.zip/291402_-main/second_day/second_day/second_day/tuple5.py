list = [10, 20, 30, 10, 40]
print(set(list))
print(tuple(list))