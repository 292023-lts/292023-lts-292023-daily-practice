import datetime
n = datetime.time(10, 12, 25)
print(n)