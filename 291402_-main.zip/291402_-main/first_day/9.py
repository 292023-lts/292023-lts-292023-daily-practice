xval = -12.785
print(abs(xval))
print(round(xval,2))