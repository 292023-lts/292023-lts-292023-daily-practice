a=10
b=2
c=0
print(a and b)
print(b and a)
print(a and c)
print(c and b)
print(a or b)
print(b or a)
print(a or c)
print(c or b)