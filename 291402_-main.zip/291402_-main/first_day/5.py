fval=2.3
ival=int(fval)
print(ival)

ch='A'
#ival=int(ch,10)
aval=ord(ch)
print(aval)

s1="2378"
ival=int(s1)
s2="45a64"
#ival=int(s2)

ival=23
s3=str(ival)
print(s3)

hval="23"
ival=int(hval,16)
print(ival)

s4="12.235"
fval=float(s4)

print(int(0x1D))
print(hex(45))
print(oct(0o23))
print(bin(13))
print(int(0b11011))


