data = [10, 20, 2.3, True, "hello", [11, 12, 13]]
print(data[5])
print(data[5][1])
print(data[4][4])

str = "abcdxyz"
print(str[0])