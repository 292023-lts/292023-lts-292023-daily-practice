var1 = 5 # 5 -10 25
if var1 > 12:
    print("var1 is above 12,")
if var1 > 20:
    print("and also above 20")
else:
    print("var1 is not above 20")