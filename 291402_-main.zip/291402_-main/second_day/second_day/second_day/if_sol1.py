n=input("Enter input:")
if(n=='lol'):
    print("laughing out loud")
if(n=='rofl'):
    print("rolling on the floor laughing")
if(n=='lmk'):
    print("let me know")
if(n=='smh'):m
    print("shaking my head")