numbers = [10, 12, 25, 48, 32, 18, 84, 63, 72, 98]
print(numbers[-1])
print(numbers[-4])
print(numbers[2:5])
print(numbers[:4])
print(numbers[:-2])
print(numbers[3:])
print(numbers[-2:])
print(numbers[:])
print(numbers[1:8:2])
print(numbers[1::2])    # [0::2], [::2]
print(numbers[5:1:-1])    # [0::2], [::2]
print(numbers[::-1])