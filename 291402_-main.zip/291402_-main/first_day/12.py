# In[ ]:
s1="abcd"
s1*=3
print(s1)
s1+="xyz"
print(s1)
print("hello " * 3)
print(4 * "hello ")