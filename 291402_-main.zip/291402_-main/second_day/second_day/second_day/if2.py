a = 4
b = 4

if a<b:
	print(a, 'is less than', b)
else:
	print(a, 'is not less than', b)