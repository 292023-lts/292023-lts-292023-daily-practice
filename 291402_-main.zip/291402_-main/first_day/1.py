a = input("enter a number:")      # let's enter 10
b = input("enter a number:")      # let's enter 20
res = a + b
print(res)
print (type(res))
print(type(a))
print(type(b))