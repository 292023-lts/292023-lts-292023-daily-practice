mylist = ["apple", "banana", "cherry"]
print(type(mylist))