# In[46]:
a=10
b=20
a=a^b
b=a^b
a=a^b
print(a,b)