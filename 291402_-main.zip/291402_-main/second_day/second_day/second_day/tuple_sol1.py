#create a tuple
t = 2, 4, 5, 6, 2, 3, 4, 4, 7
print(t)
count = t.count(4)
print(count)