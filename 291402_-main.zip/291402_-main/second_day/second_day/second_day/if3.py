var1 = 0 # var1 = 100, 0, -6
if var1:
   print ("1 - Got a true expression value")
   print ("var1=",var1)
else:
   print ("1 - Got a false expression value")
   print ("var1=",var1)

var2 = -6 # var1 = 0, 10, 100
if var2:
   print ("2 - Got a true expression value")
   print ("var1=",var2)
else:
   print ("2 - Got a false expression value")
   print ("var1=",var2)

print ("Done")