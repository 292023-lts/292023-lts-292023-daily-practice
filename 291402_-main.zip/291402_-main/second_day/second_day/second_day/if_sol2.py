n=int(input("Enter:"))
pizza=123.00
if(n%2==0):
    slice=120.00
    print(n*slice)
else:
    print(n*pizza)