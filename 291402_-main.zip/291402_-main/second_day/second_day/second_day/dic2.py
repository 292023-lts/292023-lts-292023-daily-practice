mydict = { "one" : [10,20,30], "two" : [40,50,60] }
print(mydict["two"][1])