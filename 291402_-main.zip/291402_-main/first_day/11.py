# In[ ]:
s1="10"
s2="20"
s3=int(s1)+int(s2)
print(s3)