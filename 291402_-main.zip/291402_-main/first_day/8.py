s1="Hello"
s2="Hello"
ch='e'
c2='x'
print(s1==s2)
print(s1 is s2)
print(ch in s1)
print(c2 not in s2)