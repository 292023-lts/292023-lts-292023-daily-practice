var1 = 25
if (var1 > 15):
   print("I am inside if loop")
   print("var1 is less than 15")
   print("var1=",var1)
print ("I am outside if loop")