thislist = ["apple", "banana", "cherry"]
for i in range(len(thislist)):
  print(thislist[i])