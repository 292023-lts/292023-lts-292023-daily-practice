var1 = input("Enter a number greater than 10 and less than 20: ")
var1 = int(var1)
if (var1 > 10 and var1 < 20):
    print("Entered value is in the range")
else:
    print("Please try again!")