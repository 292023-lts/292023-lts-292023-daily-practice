#!/usr/bin/env python
# coding: utf-8

# In[ ]:


"Hello Python"
print(__doc__)


