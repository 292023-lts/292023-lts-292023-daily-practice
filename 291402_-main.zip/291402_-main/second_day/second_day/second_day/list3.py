emptylist = []
print(emptylist)