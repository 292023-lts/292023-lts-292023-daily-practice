# In[ ]:
s1="abcd"
s2='xyz'
print(s1+s2)