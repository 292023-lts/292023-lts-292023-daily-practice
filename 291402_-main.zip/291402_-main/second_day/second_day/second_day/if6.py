var1 = 100 #100 5
if (var1 == 10):
   if (var1 < 15):
        print ("var1 is smaller than 15")
   if (var1 < 12):
        print ("var1 is smaller than 12 too")
   else:
        print ("var1 is greater than 15")
else:
    print("var1 is not Equal to 10")