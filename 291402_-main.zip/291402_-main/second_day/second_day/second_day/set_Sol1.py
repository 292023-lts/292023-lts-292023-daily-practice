#Create a set
s = set([5, 10, 3, 15, 2, 20])
#max
print(max(s))
#min
print(min(s))