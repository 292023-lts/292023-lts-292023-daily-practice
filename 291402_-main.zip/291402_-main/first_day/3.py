x=10
y=2.3
s1="hello"
ch='A'
flag=True
c1=2+3j
print(type(c1))
# similarly check type of others
print(isinstance(x,int))